import 'dart:developer';
import 'dart:ffi';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../model/occasion.dart';
import 'Animated/slider/slider.dart';
import 'occasion_details .dart';
// import 'package:firebase_storage/firebase_storage.dart';
class startPage extends StatefulWidget {
  const startPage({super.key});

  @override
  State<startPage> createState() => _startPageState();
}

class _startPageState extends State<startPage> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // locale: const Locale('ar'),
      // supportedLocales: const [
      //   Locale('ar'),
      //   Locale('en'),
      // ],
      // localizationsDelegates: const [
      // GlobalMaterialLocalizations.delegate,
      // GlobalCupertinoLocalizations.delegate,
      // GlobalWidgetsLocalizations.delegate,
      // ],
      title: ' مناسبتي',
      theme: ThemeData(
          fontFamily: "Cairo",
          // This is the theme of your application.
          //
          // Try running your application with "flutter run". You'll see the
          // application has a blue toolbar. Then, without quitting the app, try
          // changing the primarySwatch below to Colors.green and then invoke
          // "hot reload" (press "r" in the console where you ran "flutter run",
          // or simply save your changes to "hot reload" in a Flutter IDE).
          // Notice that the counter didn't reset back to zero; the application
          // is not restarted.

          primaryColor: Colors.white,
          hintColor: Colors.black),
      home: MyHomePage(title: 'مناسبتي '),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key? key, required this.title}) : super(key: key);

  // getdata() async {
  //   CollectionReference addNew =
  //       FirebaseFirestore.instance.collection('addNew');

  //   await addNew.get().then((QuerySnapshot snapshot) {
  //     snapshot.docs.forEach((DocumentSnapshot doc) {
  //       print(doc.data());
  //       print("++++++++++++++++++++++++");
  //     });
  //   });
  // }

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List listDepartment = [];
  CollectionReference department =
      FirebaseFirestore.instance.collection("Department");
  getDepartment() async {
    var allDepartment = await department.get();
    allDepartment.docs.forEach((element) {
      setState(() {
        listDepartment.add(element.data());
      });
      print(listDepartment);
    });
    // Nasted Collection
    // CollectionReference contentDescription = FirebaseFirestore.instance
    //     .collection("Department")
    //     .doc('0i03zAKvSSlZMXvZ2vFd')
    //     .collection('contentDep');

    // await contentDescription.get().then((value) {
    //   value.docs.forEach((element) {
    //     print(element.data());
    //     print('--------------------------------');
    //   });
    // });

    // show jaist one teble
    // var doc = FirebaseFirestore.instance
    //     .collection('Department')
    //     .doc('0i03zAKvSSlZMXvZ2vFd');
    // await doc.get().then((value) {
    //   print("${value.data()}");
    // });

    // get add data
    // FirebaseFirestore.instance
    //     .collection('Department')
    //     .get()
    //     .then((QuerySnapshot snapshot) {
    //   snapshot.docs.forEach((DocumentSnapshot doc) {
    //     print(doc.data());
    //     print("++++++++++++++++++++++++");
    //   });
    // });
    // }
    // FirebaseFirestore.instance.collection("Department").get().then((value) {
    //   value.docs.forEach((element) {
    //     print(element.data());
    //     print(
    //         "____________________________++++++++++++++_____________________");
    //   });
    // });
  }
  // QuerySnapshot snapshot =await usersRef.
  // await addNew.get().then((QuerySnapshot snapshot) {
  //   snapshot.docs.forEach((DocumentSnapshot doc) {
  //     print(doc.data());
  //     print("++++++++++++++++++++++++");

  //   });
  // });

  @override
  void initState() {
    getDepartment();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
// 1
    return Scaffold(
// 2
      appBar: AppBar(
          title: Center(child: Text("${widget.title}")),
          leading: IconButton(
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => CarSlider(),
                  ));
            },
            icon: Icon(Icons.chevron_left, size: 40.9),
          )),
// 3
      body: SafeArea(
// 4
        child: ListView.builder(
// 5
          itemCount: listDepartment.length,
// 6
          itemBuilder: (BuildContext context, int index) {
            return GestureDetector(
              // 
               onTap: () async {
// // 9
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
// 10
                      var occasion = Occasion;
                      return OccasionDetail(recipe: Occasion.samples[index]);
                    },
                  ),
                );
              },
              // 
              child: ListTile(
                title: Text("${listDepartment[index]['nameTitle']}"),
                subtitle: Text("${listDepartment[index]['Description']}"),
                
              ),
            );
// 7
//             return GestureDetector(
// // 8
//               onTap: () async {
// // 9
//                 Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                     builder: (context) {
// // 10
//                       var occasion = Occasion;
//                       return OccasionDetail(recipe: Occasion.samples[index]);
//                     },
//                   ),
//                 );
//               },
// // 11
//               child: buildRecipeCard(Occasion.samples[index]),
//             );
          },
        ),
      ),
    );
  }

  Widget buildRecipeCard(Occasion occasion) {
    return ListView.builder(
      itemCount: listDepartment.length,
      itemBuilder: (BuildContext context, int index) {
        return Card(
          // 1
          elevation: 0.1,
          // 2
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
          // 3
          child: Padding(
            padding: const EdgeInsets.all(14.0),
            // 4
            child: Column(
              children: <Widget>[
                Image(image: AssetImage(occasion.imageUrl)),
                // 5
                const SizedBox(
                  height: 10.0,
                ),
                // 6
                Text(
                  occasion.label,
                  style: const TextStyle(
                    fontSize: 20.0,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Palatino',
                  ),
                )
              ],
            ),
          ),
        );
      },
    );
  }
}
