import 'package:flutter/material.dart';

import 'Screen/Animated/SplashScreen.dart';
import 'Screen/Animated/slider/slider.dart';
import 'Screen/HomeScreen.dart';

import 'Screen/page_view.dart';
import 'Screen/start_munasbati.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      //
      theme: ThemeData(
        fontFamily: "Cairo",
      ),
      debugShowCheckedModeBanner: false,
      initialRoute: "Splash",
      routes: {
        
        "Splash": (context) => SplashScreen(),
        "Indrcion": (context) => Pview(),
        "HomeScreen": (context) => HomeScreen(),
        "CarSlider": (context) => CarSlider(),
        "startPage": (context) => startPage(),
      },
    );
  }
}