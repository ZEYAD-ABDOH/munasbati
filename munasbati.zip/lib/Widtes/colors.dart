import 'package:flutter/material.dart';

Color fwhite = const Color.fromARGB(184, 201, 199, 199);
Color white = Colors.white;
Color bkbrouwn = const Color(0xff8A6161);

